autoreconf --install

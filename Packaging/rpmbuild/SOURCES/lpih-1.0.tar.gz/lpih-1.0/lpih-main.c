/* lpih-main.c
 *
 * Copyright 2023 Samuel Petch
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

////////////////////////////////////////
////        L I B R A R I E S   ////////
////////////////////////////////////////
#include <gtk/gtk.h>

#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <X11/Xlib.h>

#include <GL/gl.h>

#include "lpih-main.h"
 //////////////////////////////
//////////////////////////////


 int gpu_manufacturer = 0;
 int cpu_manufacturer = 0;
 gchar* debian_gpu_command = NULL;
 gchar* fedora_gpu_command = NULL;

 const gchar* DEBIAN_OPENER = "  # Check the boxes according to your needs and run the resulting script in your terminal  \n  # to set up the desired functionality on your Debian system.  You may need to enable non-free  \n  # repositories by editing your '/etc/apt/sources.list' file if some of the proprietary packages  \n  # like Steam and GPU drivers don't install.  See 'tips' for details.  \n\n  sudo apt update; sudo apt upgrade;  \n  sudo apt install build-essential dkms linux-headers-$(uname -r); \n";

const gchar* DEBIAN_STEAM = "  sudo dpkg --add-architecture i386; sudo apt update; \n  sudo apt install steam-devices steam-installer; \n";

const gchar* DEBIAN_GAMING = "  sudo apt install nvidia-driver-libs:i386 mesa-vulkan-drivers libvulkan1;\n  sudo apt install vulkan-tools vulkan-validationlayers gamemode;  \n";

const gchar* DEBIAN_FLATPAK = "  sudo apt install flatpak gnome-software-plugin-flatpak; \n  sudo flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo; \n";

const gchar* DEBIAN_MULTIMEDIA = "  sudo apt install libavcodec-extra;  \n  sudo apt install gstreamer1.0-libav gstreamer1.0-plugins-ugly gstreamer1.0-vaapi;  \n  sudo apt install fonts-crosextra-carlito fonts-crosextra-caladea;  \n";

const gchar* DEBIAN_UFW = "  sudo apt install ufw; sudo ufw enable; \n";
const gchar* DEBIAN_TLP = "  sudo apt install tlp; \n";
const gchar* DEBIAN_VLC = "  sudo apt install vlc; \n";

  // For keeping track of single-instance windows.
 gboolean lpih_instance_running = FALSE;
 gboolean debian_window_open = FALSE;
 gboolean debian_tips_open = FALSE;
 gboolean fedora_window_open = FALSE;
 gboolean fedora_tips_open = FALSE;

 const gchar* debian_microcode_command;


// Large strings

const gchar* tips_spiel_fedora = "  Fedora Linux is a distribution backed by RedHat.  It has been around since 2003, and is known for using the latest versions of software in its repositories.  Fedora uses the DNF package manager, as opposed to the APT package manager in Debian. On Linux, most (if not all) of the software used is pulled from a repository specific to the Linux distro, rather than being acquired through a web browser.  Because of this, you will need to update your local repos on your computer before installing any software or updating.  This ensures that you are pulling in the latest software available in your distro's repositories.  \n\
\n\
Debian, like other Linux distributions, has a package manager; which handles the installation, updating and removal of software packages on the computer.  Debian's package manager is called apt.  In order to use some apt commands, the user must use the sudo command to elevate their privileges to those of a super-user, example: sudo apt install nvidia-driver, where nvidia-driver is the package you are trying to install.  \n\
\n\
There are some instructions for optional system configuration outlined here that you might find useful.\n\
\n\
SETTING   IP\n\
\n\
Normally, your device's unique IP address is assigned dynamically, meaning it is not necessarily going to be the same everytime it connects to your network.  You can get a slightly more stable and performant connection by setting a   IP address, where your IP is the same everytime it connects to the network.  This will also aid in configuration of firewalls and servers, since you can now specify your computer's connection by its exact IP address.  Having a   IP can be useful for a multitude of reasons, one of them being the implementation of firewall rules.  The instructions for switching to a   IP on Linux in the GNOME desktop environment are as follows:\n\
\n\
1.     Click in the top-right corner of the screen where the power icon is.  Click the gear-shaped icon to access settings.  You can also find the settings application icon by pressing the super key (Windows key or command key on Mac) and either find it visually or search settings in the searchbar that pops up with the GNOME Activities window.  This Activities window can also be accessed by clicking Activities in the tope left of the screen.\n\
\n\
2.     If you are using Wi-Fi, click on Wi-Fi at the top of the scrollable menu on the left of the settings window.  If you are using ethernet, click on Network. \n\
\n\
3.     Click on the gear icon for the network connection you are using.  Take note of the IP you are currently assigned in the IPv4 Address section of this window, under the Details tab.  When you assign a   IP to your connection, you will make one that looks very similar to this one; save for the digits after the last decimal.  So, if your IPv4 is currently 172.178.1.19 then you can likely assign yourself anything from 192.168.1.0 to 192.168.1.255, as long as the address is not in use by another network device.\n\
\n\
4.     Click the IPv4 tab, and change the method from Automatic (DHCP) to Manual.\n\
\n\
5.     In the address field, enter the   IP address you want to use.  \n\
\n\
6.     Under Netmask, enter the subnet mask for your network.  You can enter the ip addr show command to check which netmask to use.  If you are using Wi-Fi, you will be looking for an interface that looks something like wlp32s0.  Ethernet will look something like enp18s0. \n\
Beside the inet line for your interface in the terminal command output, there will be a slash follwed by a number: this is the number of bits in your subnet mask.\n\
\n\
Thus, inet 192.168.1.123/24 indicates a 24-bit netmask, which means 255.255.255.0 is your subnet mask.  \n\
\n\
- If it reads /16 then you will enter 255.255.0.0.  \n\
\n\
- For /8: 255.0.0.0 \n\
\n\
- For /25: 255.255.255.128 and finally \n\
\n\
- For /30 we have 255.255.255.252 for the subnet mask.    \n\
\n\
A subnet mask determines the size of a network: if more bits are available, then more devices can be connected.\n\
\n\
7.  Now we must determine the Gateway address, which is the address of your router.  If you have accessed your router's admin tools from your browser before by typing in an IP address, this would be the same address; and it will generally be a similar IP sequence to what you have been dealing with, but with 1 as the only digit after the last decimal, like:  XXX.XXX.X.1 \n\
So, if we are to keep with our 192.168.1.123 example, our gateway is most likely 192.168.1.1.  However, we want to be sure of this.  To confirm your gateway, use the ip route show command in the terminal.  Look for the default via line with an IP beside it.  This is your gateway address to enter. \n\
\n\
8.    Time to choose your DNS servers.  You can pick whichever one you like.  Cloudflare is popular with many, since it offers security features like DDoS protection, SSL encryption, and a web application firewall.  You can specify 2 addresses, in case one is down (seperate them with a comma in the textfield).  To use Cloudflare as your DNS provider, you can use the addresses 1.1.1.1, 1.0.0.1. For added malware protection, substitute the last 1 in each address with a 2.  OpenDNS is another popular provider that offers its own security features and malware protection, much like Cloudflare.  To use OpenDNS, use 208.67.222.222, 208.67.220.220. \n\
\n\
9.  Save your new   IP address configuration with the Apply button.  Go to your network settings and switch the connection off, then on again.  Try to connect to a webpage.  If it works, you are good to go.  If not, you may have made an error in your IP configuration.  If you need to go back to an automatically assigned IP you can undo the   IP settings by simply switching your connection from Manual to Automatic (DHCP) again in the settings. \n\n\
TROUBLESHOOTING APT PACKAGE MANAGER ON DEBIAN\n\n\
Occasionally, when trying to install software with apt on Debian, you may encounter an error with the message: \"You have held broken packages.\"  This can be fixed much of the time by following up with the following 2 commands: \n\n  sudo apt --fix-broken install\n  sudo apt install <name of package>\n\n";


 const gchar * tips_spiel_debian = "  Debian GNU/Linux is one of the oldest and most popular Linux distributions, released in 1993.  It is known for its stability and reliability: which is why it is often used for servers and other critical systems and serves as the base of many other distros, like Ubuntu and Linux Mint: Debian Edition (LMDE).\n\
\n\
Debian, like other Linux distributions, has a package manager; which handles the installation, updating and removal of software packages on the computer.  Debian's package manager is called apt.  In order to use some apt commands, the user must use the sudo command to elevate their privileges to those of a super-user, example: sudo apt install nvidia-driver, where nvidia-driver is the package you are trying to install.  \n\
\n\
There are some instructions for optional system configuration outlined here that you might find useful.\n\
\n\
SETTING   IP\n\
\n\
Normally, your device's unique IP address is assigned dynamically, meaning it is not necessarily going to be the same everytime it connects to your network.  You can get a slightly more stable and performant connection by setting a   IP address, where your IP is the same everytime it connects to the network.  This will also aid in configuration of firewalls and servers, since you can now specify your computer's connection by its exact IP address.  Having a   IP can be useful for a multitude of reasons, one of them being the implementation of firewall rules.  The instructions for switching to a   IP on Linux in the GNOME desktop environment are as follows:\n\
\n\
1.     Click in the top-right corner of the screen where the power icon is.  Click the gear-shaped icon to access settings.  You can also find the settings application icon by pressing the super key (Windows key or command key on Mac) and either find it visually or search settings in the searchbar that pops up with the GNOME Activities window.  This Activities window can also be accessed by clicking Activities in the tope left of the screen.\n\
\n\
2.     If you are using Wi-Fi, click on Wi-Fi at the top of the scrollable menu on the left of the settings window.  If you are using ethernet, click on Network. \n\
\n\
3.     Click on the gear icon for the network connection you are using.  Take note of the IP you are currently assigned in the IPv4 Address section of this window, under the Details tab.  When you assign a   IP to your connection, you will make one that looks very similar to this one; save for the digits after the last decimal.  So, if your IPv4 is currently 172.178.1.19 then you can likely assign yourself anything from 192.168.1.0 to 192.168.1.255, as long as the address is not in use by another network device.\n\
\n\
4.     Click the IPv4 tab, and change the method from Automatic (DHCP) to Manual.\n\
\n\
5.     In the address field, enter the   IP address you want to use.  \n\
\n\
6.     Under Netmask, enter the subnet mask for your network.  You can enter the ip addr show command to check which netmask to use.  If you are using Wi-Fi, you will be looking for an interface that looks something like wlp32s0.  Ethernet will look something like enp18s0. \n\
Beside the inet line for your interface in the terminal command output, there will be a slash follwed by a number: this is the number of bits in your subnet mask.\n\
\n\
Thus, inet 192.168.1.123/24 indicates a 24-bit netmask, which means 255.255.255.0 is your subnet mask.  \n\
\n\
- If it reads /16 then you will enter 255.255.0.0.  \n\
\n\
- For /8: 255.0.0.0 \n\
\n\
- For /25: 255.255.255.128 and finally \n\
\n\
- For /30 we have 255.255.255.252 for the subnet mask.    \n\
\n\
A subnet mask determines the size of a network: if more bits are available, then more devices can be connected.\n\
\n\
7.  Now we must determine the Gateway address, which is the address of your router.  If you have accessed your router's admin tools from your browser before by typing in an IP address, this would be the same address; and it will generally be a similar IP sequence to what you have been dealing with, but with 1 as the only digit after the last decimal, like:  XXX.XXX.X.1 \n\
So, if we are to keep with our 192.168.1.123 example, our gateway is most likely 192.168.1.1.  However, we want to be sure of this.  To confirm your gateway, use the ip route show command in the terminal.  Look for the default via line with an IP beside it.  This is your gateway address to enter. \n\
\n\
8.    Time to choose your DNS servers.  You can pick whichever one you like.  Cloudflare is popular with many, since it offers security features like DDoS protection, SSL encryption, and a web application firewall.  You can specify 2 addresses, in case one is down (seperate them with a comma in the textfield).  To use Cloudflare as your DNS provider, you can use the addresses 1.1.1.1, 1.0.0.1. For added malware protection, substitute the last 1 in each address with a 2.  OpenDNS is another popular provider that offers its own security features and malware protection, much like Cloudflare.  To use OpenDNS, use 208.67.222.222, 208.67.220.220. \n\
\n\
9.  Save your new   IP address configuration with the Apply button.  Go to your network settings and switch the connection off, then on again.  Try to connect to a webpage.  If it works, you are good to go.  If not, you may have made an error in your IP configuration.  If you need to go back to an automatically assigned IP you can undo the   IP settings by simply switching your connection from Manual to Automatic (DHCP) again in the settings. \n\n\
TROUBLESHOOTING APT PACKAGE MANAGER ON DEBIAN\n\n\
Occasionally, when trying to install software with apt on Debian, you may encounter an error with the message: \"You have held broken packages.\"  This can be fixed much of the time by following up with the following 2 commands: \n\n  sudo apt --fix-broken install\n  sudo apt install <name of package>\n\n";

const gchar* FEDORA_OPENER = "  # Check the boxes according to your needs and run the resulting script in your terminal  \n  # to set up the desired functionality on your Fedora system.  \n\n  sudo dnf update; sudo dnf upgrade; \n";


const gchar* FEDORA_REP = "  sudo dnf install https://download1.rpmfusion.org/free/fedora/rpmfusion-free-release-$(rpm -E %fedora).noarch.rpm;  \n  sudo dnf install https://download1.rpmfusion.org/nonfree/fedora/rpmfusion-nonfree-release-$(rpm -E %fedora).noarch.rpm;  \n  sudo dnf update; \n";

const gchar* FEDORA_STEAM = "  sudo dnf install steam;\n";

const gchar* FEDORA_DNF = "  sudo sh -c 'if test -f /etc/dnf/dnf.conf; then echo \"max_parallel_downloads=20\" >> /etc/dnf/dnf.conf; fi'\n";

const gchar* FEDORA_FLATPAK = "  flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo; \n";

const gchar* FEDORA_CUST = "  sudo dnf install gnome-tweaks gnome-extensions-app; \n";



const gchar* FEDORA_MULTIMEDIA = "  sudo dnf install ffmpeg --allowerasing &&  \n  sudo dnf install gstreamer1-plugins-{bad-\\*,good-\\*,base} gstreamer1-plugin-openh264 gstreamer1-libav --exclude=gstreamer1-plugins-bad-free-devel &&  \n  sudo dnf install lame\\* --exclude=lame-devel && sudo dnf group upgrade --with-optional Multimedia \n";

const gchar* FEDORA_TLP = "  sudo dnf install tlp; \n";

const gchar* FEDORA_VLC = "  sudo dnf install vlc; \n";

 // UTILITY FUNCTIONS //

// Function to get the graphics card vendor of the user.
const gchar* getGraphicsCardVendor(void) {
  gchar* gpu_driver;
  g_print("Started getGraphicsCardVendor()");
  gpu_driver = (gchar*) glGetString(GL_VENDOR);
  if (!gpu_driver) {
    g_print("Failed to get GPU vendor.\n");
    return "Unknown";
  } else {
    g_print("Finish getGraphicsCardVendor: %s \n", gpu_driver);
  return gpu_driver;
  }
}

gboolean get_cpu_vendor(gchar * vendor) {
  unsigned int eax, ebx, ecx, edx;

  // Call cpuid with input 0 to get vendor string
  __asm__("cpuid": "=a"(eax), "=b"(ebx), "=c"(ecx), "=d"(edx): "a"(0));

  // Copy the vendor string to the output buffer
  ((int * ) vendor)[0] = ebx;
  ((int * ) vendor)[1] = edx;
  ((int * ) vendor)[2] = ecx;
  vendor[12] = '\0';

  if (vendor != NULL) {
    g_print("CPU vendor loaded.\n");
    return TRUE;
  } else {
    g_print("*********ERROR: Problem getting cpu vendor info.*****\n\n");
    return FALSE;
  }

}

const gchar* gpu_vendor;

gboolean set_gpu_mfg(void) {
  gpu_vendor = getGraphicsCardVendor();
  g_print("Started set_gpu_mfg()\n");
  if (strstr(gpu_vendor, "NVIDIA") != NULL) {
    gpu_manufacturer = 1;
  } else if (strstr(gpu_vendor, "AMD") != NULL) {
    gpu_manufacturer = 2;
  } else if (strstr(gpu_vendor, "Intel") != NULL) {
    gpu_manufacturer = 3;
  } else {
    g_print("******ERROR: The GPU vendor could not be determined for this GPU. GPU = 0 ******\n");
    gpu_manufacturer = 0;
    g_print("Ended set_gpu_mfg() 0\n");
    return TRUE;
  }
      g_print("Ended set_gpu_mfg()\n");
    g_print("The GPU manufacturer for this machine is %s.\n", gpu_vendor);
    return TRUE;

}

gboolean set_gpu_commands(void) {
  g_print("Started set_gpu_commands()");
  if (gpu_manufacturer == 1) {
    debian_gpu_command = "  sudo apt install nvidia-driver nvidia-driver-libs;\n";
    fedora_gpu_command = "  sudo dnf install akmod-nvidia xorg-x11-drv-nvidia-cuda \n";
    return TRUE;

  } else if (gpu_manufacturer == 2) {
    debian_gpu_command = "  sudo apt install firmware-linux firmware-linux-nonfree libdrm-amdgpu1 xserver-xorg-video-amdgpu;\n";
    fedora_gpu_command = "  sudo dnf install xorg-x11-drv-amdgpu vulkan-tools mesa-vulkan-drivers \n";
    return TRUE;

  } else if (gpu_manufacturer == 3) {
    debian_gpu_command = "  # Intel GPU drivers already installed. \n";
    fedora_gpu_command = "  # Intel GPU drivers already installed. \n";
    return TRUE;

  } else if (gpu_manufacturer == 0) {
    debian_gpu_command = "******ERROR: The GPU vendor could not be determined for this GPU.******\n";
    fedora_gpu_command = "******ERROR: The GPU vendor could not be determined for this GPU.******\n";
      g_print("ERROR in set_gpu_commands(): can't get gpu mfg.\n");
    return TRUE;
  } else {
          g_print("Failed to set gpu_commands.\n");
          return FALSE;
          }

}

// Print a line of asterisks of the specified length.
gboolean print_asterisk_line(int asterisk_qty) {
  int z;
  for (z = 0; z < asterisk_qty; z++) {
    g_print("*");
  }
  g_print("\n\n");
  return TRUE;
}




// GPU / CPU INFORMATION

gboolean set_cpu_mfg(void) {

  gchar vendor[12];
  get_cpu_vendor(vendor);

  if (strstr(vendor, "AMD") != NULL) {
    cpu_manufacturer = 2;
    g_print("The CPU manufacturer for this machine is %s.\n", vendor);
    print_asterisk_line(37);
    return TRUE;

  } else if (strstr(vendor, "Intel") != NULL) {
    cpu_manufacturer = 3;
    g_print("The CPU manufacturer for this machine is %s.\n", vendor);
    print_asterisk_line(37);
    return TRUE;

  } else {
    g_print("*****ERROR: The CPU vendor could not be determined for this computer.\n");
    print_asterisk_line(37);
    cpu_manufacturer = 0;
    return FALSE;
  }
}

int set_cpu_commands(void) {

  if (cpu_manufacturer == 2) {
    debian_microcode_command = "  sudo apt install amd64-microcode;\n";
  } else if (cpu_manufacturer == 3) {
    debian_microcode_command = "  sudo apt install intel-microcode;\n";
  } else {
    g_print("*****ERROR: Something went wrong trying to get the cpu manufacturer.*****\n");
    return FALSE;
  }
  
    return TRUE;
}



 
 
const gchar* whichCssPath(void) {

  const gchar* cssFilePathDecided = NULL;
  const gchar* cssPathForAppInstalled = "/usr/share/LPIH/css/style.css";
  const gchar* cssPathForAppInSrc = "./Resources/style.css";

  FILE* cssFileForAppInstalled = fopen(cssPathForAppInstalled, "r");
  FILE* cssFileForAppInSrc = fopen(cssPathForAppInSrc, "r");

  if (cssFileForAppInSrc) {
    g_print("The CSS file was found in the project directory.\n");
    cssFilePathDecided = cssPathForAppInSrc;
    fclose(cssFileForAppInSrc);
    return cssFilePathDecided;

  } else if (cssPathForAppInstalled) {
    g_print("The CSS file was found in /usr/share/LPIH/css");
    cssFilePathDecided = cssPathForAppInstalled;
    fclose(cssFileForAppInstalled);
    return cssFilePathDecided;

  } else {
    print_asterisk_line(41);
    g_print("ERROR: Can't find the CSS file!  Please report this to the LPIH maintainer so it can be fixed.\n");
    print_asterisk_line(41);
    return NULL;
  }
}

gboolean init_css_provider(void) {

  GtkCssProvider * provider = gtk_css_provider_new();

  const gchar * cssFilePathDecided = whichCssPath();
  gtk_css_provider_load_from_path(provider, cssFilePathDecided);
  gtk_style_context_add_provider_for_display(gdk_display_get_default(), GTK_STYLE_PROVIDER(provider), GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);

  if (provider != NULL) {
    g_print("The CSS provider has found the CSS file.  \n");
    return TRUE;

  } else {
    g_print("******ERROR: CSS provider failed to find the CSS file in function gtk_css_provider_load_from_path(). \n");
    return 2;
  }

}


////////////////////////////////////////////
///// INFORMATIONAL WINDOW: DEBIAN /////////
///////////////////////////////////////////

gboolean on_deb_tips_window_destroy(void) {
  debian_tips_open = FALSE;

  if (!(debian_tips_open)) {
    g_print("debian_tips_open set to 0.\n");
    return TRUE;
  } else {
    g_print("debian_tips_open is NULL.  Failed to set to 0.\n");
    return FALSE;
  }
}

gboolean debian_info_window(void) {

  if (!(debian_tips_open)) {

    GtkWidget* deb_info_window;
    GtkWidget* deb_info_box;

    deb_info_window = gtk_window_new();
    gtk_widget_add_css_class(deb_info_window, "deb_info_window");
    gtk_window_set_title(GTK_WINDOW(deb_info_window), "Debian: tips");
    gtk_window_set_resizable(GTK_WINDOW(deb_info_window), FALSE);
    gtk_window_set_default_size(GTK_WINDOW(deb_info_window), 700, 700);

    GtkWidget* view;
    GtkTextBuffer * buffer;

    deb_info_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_window_set_child(GTK_WINDOW(deb_info_window), deb_info_box);

    // Create a scrolled window and set the size
    GtkWidget* scroll_info_window = gtk_scrolled_window_new();

    gtk_widget_set_size_request(scroll_info_window, 700, 700);

    view = gtk_text_view_new();
    gtk_widget_set_opacity(view, 0.9);
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(view), GTK_WRAP_WORD_CHAR);
    gtk_widget_add_css_class(view, "deb_info_view");
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(view));
    gtk_text_buffer_set_text(buffer, tips_spiel_debian, -1);

    gtk_text_view_set_editable(GTK_TEXT_VIEW(view), FALSE);
    gtk_widget_set_can_focus(GTK_WIDGET(view), TRUE);
    gtk_text_view_set_left_margin(GTK_TEXT_VIEW(view), 13);
    gtk_text_view_set_right_margin(GTK_TEXT_VIEW(view), 13);
    gtk_scrolled_window_set_child(GTK_SCROLLED_WINDOW(scroll_info_window), view);

    gtk_box_append(GTK_BOX(deb_info_box), scroll_info_window);

    g_signal_connect(deb_info_window, "destroy", G_CALLBACK(on_deb_tips_window_destroy), NULL);

    gtk_widget_set_visible(deb_info_window, TRUE);

      if (gtk_widget_is_visible(deb_info_window)) {
        debian_tips_open = 1;
        return TRUE;
         } else {
             g_print("Debian LPIH window failed to open.");
             return FALSE;
         }

  } else {
    g_print("debian_tips window is already open.");
    return TRUE;
  }
}

gboolean debian_window(void) {

  if (!(debian_window_open)) {

    GtkWidget* deb_window, * deb_box, * deb_gpu_check, * deb_steam_check, * deb_game_check, * deb_flatpak_check, * deb_microcode_check, * deb_fonts_check, * deb_ufw_check, * deb_tlp_check, * deb_vlc_check, * deb_info_button;

    deb_window = gtk_window_new();
    gtk_widget_add_css_class(deb_window, "deb_window");
    gtk_window_set_title(GTK_WINDOW(deb_window), "Linux Post-install Helper: Debian");
    gtk_window_set_resizable(GTK_WINDOW(deb_window), FALSE);
    gtk_window_set_default_size(GTK_WINDOW(deb_window), 960, 700);
    gtk_widget_set_can_focus(GTK_WIDGET(deb_window), TRUE);

    GtkWidget* view;
    GtkTextBuffer * buffer;

    deb_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_window_set_child(GTK_WINDOW(deb_window), deb_box);
    gtk_widget_set_can_focus(GTK_WIDGET(deb_box), TRUE);

    // CHECKBOXES //////////

    deb_steam_check = gtk_check_button_new_with_label("  Do you plan on using steam?");
    gtk_box_append(GTK_BOX(deb_box), deb_steam_check);

    deb_game_check = gtk_check_button_new_with_label("  Do you plan on playing video games?");
    gtk_box_append(GTK_BOX(deb_box), deb_game_check);

    deb_flatpak_check = gtk_check_button_new_with_label("  Do you want to use flatpak applications?");
    gtk_box_append(GTK_BOX(deb_box), deb_flatpak_check);

    deb_microcode_check = gtk_check_button_new_with_label("  Install your processor's latest microcode?");
    gtk_box_append(GTK_BOX(deb_box), deb_microcode_check);

    deb_fonts_check = gtk_check_button_new_with_label("  Install restricted fonts compatibility for Microsoft products and multimedia compatibility packages?");
    gtk_box_append(GTK_BOX(deb_box), deb_fonts_check);

    deb_ufw_check = gtk_check_button_new_with_label("  Do you want to install ufw? (uncomplicated firewall)");
    gtk_box_append(GTK_BOX(deb_box), deb_ufw_check);

    deb_tlp_check = gtk_check_button_new_with_label("  Install tlp for laptop power management?");
    gtk_box_append(GTK_BOX(deb_box), deb_tlp_check);

    deb_vlc_check = gtk_check_button_new_with_label("  Install vlc to play unsupported media formats?");
    gtk_box_append(GTK_BOX(deb_box), deb_vlc_check);

    deb_gpu_check = gtk_check_button_new_with_label("  Install applicable GPU drivers?");
    gtk_box_append(GTK_BOX(deb_box), deb_gpu_check);

    // Create a scrolled window and set the size
    GtkWidget* scroll_window = gtk_scrolled_window_new();

    gtk_widget_set_size_request(scroll_window, 400, 300);
    gtk_widget_set_can_focus(GTK_WIDGET(scroll_window), TRUE);

    view = gtk_text_view_new();
    gtk_widget_set_opacity(view, 0.9);
    gtk_widget_add_css_class(view, "deb_view");
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(view));
    gtk_text_buffer_set_text(buffer, DEBIAN_OPENER, -1);
    gtk_text_view_set_editable(GTK_TEXT_VIEW(view), FALSE);
    gtk_widget_set_can_focus(GTK_WIDGET(view), TRUE);
    gtk_scrolled_window_set_child(GTK_SCROLLED_WINDOW(scroll_window), view);
    gtk_box_append(GTK_BOX(deb_box), scroll_window);
 
    //     DEBIAN INFO WINDOW   ///
    // Create separate box to hold button to solve sizing issues //////
    GtkWidget* deb_info_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_append(GTK_BOX(deb_box), deb_info_box);
    // create info button for Debian window //

    deb_info_button = gtk_button_new_with_label("Tips");
    gtk_widget_add_css_class(view, "deb_info_button");
    gtk_widget_set_size_request(deb_info_button, 100, 100);
    gtk_widget_add_css_class(deb_info_button, "deb_info_button");
    gtk_box_append(GTK_BOX(deb_info_box), deb_info_button);

    // CONNECT WIDGET CLICKS TO CALLBACK FUNCTIONS //

    g_signal_connect(deb_info_button, "clicked", G_CALLBACK(debian_info_window), NULL);

    g_signal_connect(G_OBJECT(deb_gpu_check), "toggled", G_CALLBACK(deb_gpu_toggled), buffer);
    g_signal_connect(G_OBJECT(deb_steam_check), "toggled", G_CALLBACK(deb_steam_toggled), buffer);
    g_signal_connect(G_OBJECT(deb_game_check), "toggled", G_CALLBACK(deb_game_toggled), buffer);
    g_signal_connect(G_OBJECT(deb_flatpak_check), "toggled", G_CALLBACK(deb_flatpak_toggled), buffer);
    g_signal_connect(G_OBJECT(deb_microcode_check), "toggled", G_CALLBACK(deb_microcode_toggled), buffer);
    g_signal_connect(G_OBJECT(deb_fonts_check), "toggled", G_CALLBACK(deb_fonts_toggled), buffer);
    g_signal_connect(G_OBJECT(deb_ufw_check), "toggled", G_CALLBACK(deb_ufw_toggled), buffer);
    g_signal_connect(G_OBJECT(deb_tlp_check), "toggled", G_CALLBACK(deb_tlp_toggled), buffer);
    g_signal_connect(G_OBJECT(deb_vlc_check), "toggled", G_CALLBACK(deb_vlc_toggled), buffer);
    g_signal_connect(deb_window, "destroy", G_CALLBACK(on_deb_window_destroy), NULL);

    gtk_widget_set_visible(deb_window, TRUE);

    ///////////////////////
    if (gtk_widget_is_visible(deb_window)) {
      debian_window_open = TRUE;
      return TRUE;
    } else {
      g_print("Debian LPIH window failed to open.");
      return FALSE;
    }
    ///////////////////////
  } else { g_print("This window is already open.");
            return TRUE;
           }
}

// This function is used to add and remove the commands from the GUI based on the status of the checkboxes. 
gboolean check_box_state(const gchar * command_string, GtkWidget* widget, gpointer data) {

  gboolean state = gtk_check_button_get_active(GTK_CHECK_BUTTON(widget));
  GtkTextBuffer * buffer = GTK_TEXT_BUFFER(data);

  GtkTextIter iter;
  if (state) {
    gtk_text_buffer_get_end_iter(buffer, & iter);
    gtk_text_buffer_insert(buffer, & iter, command_string, -1);
  } else {
    GtkTextIter start, end, match_start, match_end;
    const gchar * search_string = command_string;

    gtk_text_buffer_get_start_iter(buffer, & start);
    gtk_text_buffer_get_end_iter(buffer, & end);

    if (gtk_text_iter_forward_search( & start, search_string, 0, & match_start, & match_end, NULL)) {
      gtk_text_buffer_delete(buffer, & match_start, & match_end);
    }
  }
  return TRUE;
}

////////// DEBIAN GPU DRIVERS CHECKBOX ///////////////
gboolean deb_gpu_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(debian_gpu_command, widget, data);
  return TRUE;
}
//// DEBIAN STEAM CHECKBOX ///////
gboolean deb_steam_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(DEBIAN_STEAM, widget, data);
    return TRUE;
}
//// DEBIAN GAME CHECKBOX ///////
gboolean deb_game_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(DEBIAN_GAMING, widget, data);
  return TRUE;
}
////////// DEBIAN FLATPAK CHECKBOX ///////////////
gboolean deb_flatpak_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(DEBIAN_FLATPAK, widget, data);
  return TRUE;
}
//// DEBIAN MICROCODE CHECKBOX ///////
gboolean deb_microcode_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(debian_microcode_command, widget, data);
  return TRUE;
}
//// DEBIAN FONTS CHECKBOX ///////
gboolean deb_fonts_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(DEBIAN_MULTIMEDIA, widget, data);
  return TRUE;
}
////////// DEBIAN UFW CHECKBOX ///////////////
gboolean deb_ufw_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(DEBIAN_UFW, widget, data);
  return TRUE;
}
//// DEBIAN TLP CHECKBOX ///////
gboolean deb_tlp_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(DEBIAN_TLP, widget, data);
  return TRUE;
}
//// DEBIAN VLC CHECKBOX ///////
gboolean deb_vlc_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(DEBIAN_VLC, widget, data);
  return TRUE;
}

///// Do this when the main window is closed. ////////
gboolean on_deb_window_destroy(void) {
  debian_window_open = FALSE;
  return TRUE;
}

/////////////////////////////////////////////////////
// INFORMATIONAL WINDOW: FEDORA /////////////////////
// //////////////////////////////////////////////////

int fedora_info_window(void) {

  if (fedora_tips_open != TRUE) {

    GtkWidget* fed_info_window;
    GtkWidget* fed_info_box;

    fed_info_window = gtk_window_new();
    gtk_window_set_title(GTK_WINDOW(fed_info_window), "Fedora: tips");
    gtk_window_set_resizable(GTK_WINDOW(fed_info_window), FALSE);
    gtk_window_set_default_size(GTK_WINDOW(fed_info_window), 700, 700);

    GtkWidget* view;
    GtkTextBuffer * buffer;

    fed_info_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_window_set_child(GTK_WINDOW(fed_info_window), fed_info_box);

    // Create a scrolled window and set the size
    GtkWidget* scroll_info_window = gtk_scrolled_window_new();

    gtk_widget_set_size_request(scroll_info_window, 700, 700);

    view = gtk_text_view_new();
    gtk_widget_set_opacity(view, 0.9);
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(view), GTK_WRAP_WORD_CHAR);
    gtk_widget_add_css_class(view, "fed_info_view");
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(view));
    gtk_text_buffer_set_text(buffer, tips_spiel_fedora, -1);

    gtk_text_view_set_editable(GTK_TEXT_VIEW(view), FALSE);
    gtk_widget_set_can_focus(GTK_WIDGET(view), True);
    gtk_text_view_set_left_margin(GTK_TEXT_VIEW(view), 13);
    gtk_text_view_set_right_margin(GTK_TEXT_VIEW(view), 13);
    gtk_scrolled_window_set_child(GTK_SCROLLED_WINDOW(scroll_info_window), view);
    gtk_box_append(GTK_BOX(fed_info_box), scroll_info_window);

    g_signal_connect(fed_info_window, "destroy", G_CALLBACK(on_fed_tips_window_destroy), NULL);

    gtk_widget_set_visible(fed_info_window, TRUE);

     if (gtk_widget_is_visible(fed_info_window)) {
        fedora_tips_open = TRUE;
        return TRUE;
         } else {
             g_print("Fedora LPIH window failed to open.");
             return FALSE;
         }

  } else {
    g_print("Error: Fedora Tips already open.");
    return TRUE;
  }

}

gboolean on_fed_tips_window_destroy() {
  fedora_tips_open = FALSE;
  if (fedora_tips_open == FALSE) {
    g_print("fedora_tips_open set to FALSE.\n");
    return TRUE;
  } else {
    g_print("fedora_tips_open is NULL.  Failed to set to FALSE.\n");
    return FALSE;
  }
}

//////////////////////////////////////////
//                                     || //
//      FEDORA WINDOW AND FUNCTIONS   |  |  ||
//                                     || //
//////////////////////////////////////////

int fedora_window(void) {

  if (fedora_window_open != TRUE) {

    GtkWidget* fed_window;
    GtkWidget* fed_box, * fed_gpu_check, * fed_steam_check, * fed_dnf_check, * fed_flatpak_check, * fed_repo_check, * fed_customization_check, * fed_codecs_check, * fed_tlp_check, * fed_vlc_check, * fed_info_button;
    fed_window = gtk_window_new();
    gtk_widget_add_css_class(fed_window, "fed_window");
    gtk_window_set_title(GTK_WINDOW(fed_window), "Linux Post-install Helper: Fedora");
    gtk_window_set_resizable(GTK_WINDOW(fed_window), FALSE);
    gtk_window_set_default_size(GTK_WINDOW(fed_window), 960, 700);
    gtk_widget_set_can_focus(GTK_WIDGET(fed_window), TRUE);

    GtkWidget* view;
    GtkTextBuffer * buffer;

    fed_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_window_set_child(GTK_WINDOW(fed_window), fed_box);

    // FEDORA CHECKBOXES //////////

    fed_dnf_check = gtk_check_button_new_with_label("  Optimize the dnf package manager for faster downloads?");
    gtk_box_append(GTK_BOX(fed_box), fed_dnf_check);

    fed_repo_check = gtk_check_button_new_with_label("  Enable RPM-fusion repositories for wider range of software?");
    gtk_box_append(GTK_BOX(fed_box), fed_repo_check);

    fed_steam_check = gtk_check_button_new_with_label("  Do you plan on using steam?");
    gtk_box_append(GTK_BOX(fed_box), fed_steam_check);

    fed_flatpak_check = gtk_check_button_new_with_label("  Do you want to use flatpak applications?");
    gtk_box_append(GTK_BOX(fed_box), fed_flatpak_check);

    fed_customization_check = gtk_check_button_new_with_label("  Install gnome-tweaks and gnome-extensions for desktop customization?");
    gtk_box_append(GTK_BOX(fed_box), fed_customization_check);

    fed_codecs_check = gtk_check_button_new_with_label("  Do you want to install multimedia codecs for unsupported media formats?");
    gtk_box_append(GTK_BOX(fed_box), fed_codecs_check);

    fed_tlp_check = gtk_check_button_new_with_label("  Install tlp for laptop power management?");
    gtk_box_append(GTK_BOX(fed_box), fed_tlp_check);

    fed_vlc_check = gtk_check_button_new_with_label("  Install vlc to play unsupported media formats?");
    gtk_box_append(GTK_BOX(fed_box), fed_vlc_check);

    fed_gpu_check = gtk_check_button_new_with_label("  Install applicable GPU drivers?");
    gtk_box_append(GTK_BOX(fed_box), fed_gpu_check);

    // Create a scrolled window and set the size
    GtkWidget* scroll_window = gtk_scrolled_window_new();

    gtk_widget_set_size_request(scroll_window, 400, 300);

    view = gtk_text_view_new();
    gtk_widget_set_opacity(view, 0.9);

    gtk_widget_add_css_class(view, "fed_view");
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(view));
    gtk_text_buffer_set_text(buffer, FEDORA_OPENER, -1);
    gtk_text_view_set_editable(GTK_TEXT_VIEW(view), FALSE);
    gtk_widget_set_can_focus(GTK_WIDGET(view), TRUE);
    gtk_scrolled_window_set_child(GTK_SCROLLED_WINDOW(scroll_window), view);
    gtk_box_append(GTK_BOX(fed_box), scroll_window);

    // FEDORA INFO WINDOW //

    // Create separate box to hold button to solve sizing issues //////
    GtkWidget* fed_info_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_append(GTK_BOX(fed_box), fed_info_box);
    // create info button for Debian window //

    fed_info_button = gtk_button_new_with_label("Tips");
    gtk_widget_add_css_class(view, "fed_info_button");
    gtk_widget_set_size_request(fed_info_button, 100, 100);
    gtk_widget_add_css_class(fed_info_button, "fed_info_button");
    gtk_box_append(GTK_BOX(fed_info_box), fed_info_button);

    // Connect checkbox functions to checkboxes ///
    g_signal_connect(fed_info_button, "clicked", G_CALLBACK(fedora_info_window), NULL);

    g_signal_connect(G_OBJECT(fed_gpu_check), "toggled", G_CALLBACK(fed_gpu_toggled), buffer);
    g_signal_connect(G_OBJECT(fed_steam_check), "toggled", G_CALLBACK(fed_steam_toggled), buffer);
    g_signal_connect(G_OBJECT(fed_dnf_check), "toggled", G_CALLBACK(fed_dnf_toggled), buffer);
    g_signal_connect(G_OBJECT(fed_flatpak_check), "toggled", G_CALLBACK(fed_flatpak_toggled), buffer);
    g_signal_connect(G_OBJECT(fed_repo_check), "toggled", G_CALLBACK(fed_repo_toggled), buffer);
    g_signal_connect(G_OBJECT(fed_customization_check), "toggled", G_CALLBACK(fed_customization_toggled), buffer);
    g_signal_connect(G_OBJECT(fed_codecs_check), "toggled", G_CALLBACK(fed_codecs_toggled), buffer);
    g_signal_connect(G_OBJECT(fed_tlp_check), "toggled", G_CALLBACK(fed_tlp_toggled), buffer);
    g_signal_connect(G_OBJECT(fed_vlc_check), "toggled", G_CALLBACK(fed_vlc_toggled), buffer);
    g_signal_connect(fed_window, "destroy", G_CALLBACK(on_fed_window_destroy), NULL);

    gtk_widget_set_visible(fed_window, TRUE);

    if (gtk_widget_is_visible(fed_window)) {
      fedora_window_open = TRUE;
      return TRUE;
    } else {
      g_print("Fedora window failed to open.");
      return FALSE;
    }
  } else {
        g_print("This window is already open!");
        return TRUE;
        }
}

//// FEDORA REPO CHECKBOX ///////
gboolean fed_repo_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(FEDORA_REP, widget, data);
  return TRUE;
}
////////// FEDORA GPU CHECKBOX ///////////////
gboolean fed_gpu_toggled(GtkWidget* widget, gpointer data) {
 check_box_state(fedora_gpu_command, widget, data); 
    return TRUE;
    } 

//// FEDORA STEAM CHECKBOX ///////
gboolean fed_steam_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(FEDORA_STEAM, widget, data);
  return TRUE;
}
//// FEDORA DNF SETTINGS CHECKBOX ///////
gboolean fed_dnf_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(FEDORA_DNF, widget, data);
  return TRUE;
}
////////// FEDORA FLATPAK CHECKBOX ///////////////
gboolean fed_flatpak_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(FEDORA_FLATPAK, widget, data);
  return TRUE;
}
//// FEDORA CUSTOMIZATION CHECKBOX ///////
gboolean fed_customization_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(FEDORA_CUST, widget, data);
  return TRUE;
}
////////// FEDORA CODECS CHECKBOX ///////////////
gboolean fed_codecs_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(FEDORA_MULTIMEDIA, widget, data);
  return TRUE;
}
//// FEDORA TLP CHECKBOX ///////
gboolean fed_tlp_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(FEDORA_TLP, widget, data);
  return TRUE;
}
//// FEDORA VLC CHECKBOX ///////
gboolean fed_vlc_toggled(GtkWidget* widget, gpointer data) {
  check_box_state(FEDORA_VLC, widget, data);
  return TRUE;
}

gboolean on_fed_window_destroy(void) {
  fedora_window_open = FALSE;
  if (!(fedora_window_open)) {
    g_print("Set fedora_window_open to FALSE.  Window closed.\n");
    return TRUE;
    
  } else {
        g_print("Failed to set fedora_window_open to FALSE.\n");
        return FALSE; 
      }
}


GtkWidget* create_grid(void) {
    
    GtkWidget* grid;
    grid = gtk_grid_new();
    gtk_grid_set_row_homogeneous(GTK_GRID(grid), TRUE); 
    gtk_grid_set_column_homogeneous(GTK_GRID(grid), TRUE); 
    gtk_grid_set_row_spacing(GTK_GRID(grid), 50);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 100);
    gtk_grid_set_row_homogeneous(GTK_GRID(grid), TRUE);
    
    if (grid != NULL) {
      return grid;
    } else { return NULL; }
}

////// INITIAL WINDOW ////////////////////////////////////////////////////

int activate(GtkApplication* app) {

  if (lpih_instance_running != TRUE) {

    lpih_instance_running = TRUE;

    GtkWidget* window;
    GtkWidget* grid;
    GtkWidget* deb_button;
    GtkWidget* fed_button;
    GtkWidget* quit_button;

    window = gtk_application_window_new(app);

    gtk_widget_add_css_class(window, "main_window");
    gtk_window_set_title(GTK_WINDOW(window), "Linux Post-install Helper For Debian and Fedora");
    gtk_widget_set_size_request(window, 444, 444);
    gtk_window_set_resizable(GTK_WINDOW(window), FALSE);

    /////////////////////////////////////////////////////////////////////////

    grid = create_grid();
    gtk_window_set_child(GTK_WINDOW(window), grid);
    deb_button = gtk_button_new_with_label("DEBIAN");
    gtk_widget_add_css_class(deb_button, "deb");
    
    g_signal_connect(deb_button, "clicked", G_CALLBACK(debian_window), NULL);
    gtk_grid_attach(GTK_GRID(grid), deb_button, 0, 0, 1, 1);
    fed_button = gtk_button_new_with_label("FEDORA");
    gtk_widget_add_css_class(fed_button, "fed");
    
    g_signal_connect(fed_button, "clicked", G_CALLBACK(fedora_window), NULL);
    gtk_grid_attach(GTK_GRID(grid), fed_button, 1, 0, 1, 1);
    quit_button = gtk_button_new_with_label("QUIT");
    gtk_widget_add_css_class(quit_button, "quit");
    gtk_widget_set_name(quit_button, "quit");
    
    g_signal_connect_swapped(quit_button, "clicked", G_CALLBACK(gtk_window_destroy), window);
    gtk_grid_attach(GTK_GRID(grid), quit_button, 0, 1, 2, 1);
    gtk_widget_set_halign(grid, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(grid, GTK_ALIGN_CENTER);
    init_css_provider();
    gtk_widget_set_can_focus(GTK_WIDGET(window), TRUE);
    gtk_widget_set_can_focus(GTK_WIDGET(grid), TRUE);
    gtk_widget_set_visible(window, TRUE);

    // Set the GPU & CPU manufacturers, plus their respective commands for driver installation..
    
    set_gpu_mfg();
    set_gpu_commands();
    set_cpu_mfg();
    set_cpu_commands();

    g_print("Activate complete.\n");
    return 0;
    
  } else if (lpih_instance_running == TRUE) {
      g_print("Instance of LPIH is already running!\n");
      return 0;
  } else {
      
      g_print("Error in function: activate.\n");
      return 1;
     
     }
}

gboolean on_quit(void) {

  g_print("Exiting LPIH now.\n");
  print_asterisk_line(37);
  lpih_instance_running = FALSE;
  
  if (lpih_instance_running == FALSE) {
    g_print("lpih_instance_running set to FALSE.\n\n");
    return TRUE;
  } else {
           g_print("Error setting lpih_instance_running to FALSE.\n\n");
           return FALSE;
          }
}

int main(int argc, char ** argv) {

  GtkApplication* app;
  int status;
  app = gtk_application_new("imperialslug.gtkproject.lpih", G_APPLICATION_DEFAULT_FLAGS);
  g_signal_connect(app, "activate", G_CALLBACK(activate), NULL);
  g_signal_connect(app, "shutdown", G_CALLBACK(on_quit), NULL);
  status = g_application_run(G_APPLICATION(app), argc, argv);
  g_object_unref(app);

  return status;
}




///////////// END OF FILE /////////////

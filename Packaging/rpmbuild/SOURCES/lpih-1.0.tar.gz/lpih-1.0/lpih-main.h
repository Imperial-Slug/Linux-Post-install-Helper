#ifndef LPIH_MAIN_H
#define LPIH_MAIN_H


//\\//\\//\\//\\//\\// DEBIAN-WINDOW FUNCTIONS //\\//\\//\\//\\//\\//\\//\\//|||||||||
 gboolean deb_gpu_toggled(GtkWidget * widget, gpointer data);
 gboolean deb_steam_toggled(GtkWidget * widget, gpointer data);
 gboolean deb_game_toggled(GtkWidget * widget, gpointer data);
 gboolean deb_flatpak_toggled(GtkWidget * widget, gpointer data);
 gboolean deb_microcode_toggled(GtkWidget * widget, gpointer data);
 gboolean deb_fonts_toggled(GtkWidget * widget, gpointer data);
 gboolean deb_ufw_toggled(GtkWidget * widget, gpointer data);
 gboolean deb_tlp_toggled(GtkWidget * widget, gpointer data);
 gboolean deb_vlc_toggled(GtkWidget * widget, gpointer data);
 gboolean on_deb_window_destroy(void);
 gboolean on_deb_tips_window_destroy(void);
gboolean on_quit(void);
 // Function to get the CPU vendor strings. // // // // // // // // // // // // // // //
 gboolean get_cpu_vendor(char * vendor);
 gboolean set_cpu_commands();
 
 gboolean init_css_provider();
 const gchar* whichCssPath(void); 

 //\\//\\//\\//\\//\\// FEDORA-WINDOW FUNCTIONS //\\//\\//\\//\\//\\//\\//\\//||||||||||
 gboolean fed_gpu_toggled(GtkWidget * widget, gpointer data);
 gboolean fed_steam_toggled(GtkWidget * widget, gpointer data);
 gboolean fed_dnf_toggled(GtkWidget * widget, gpointer data);
 gboolean fed_flatpak_toggled(GtkWidget * widget, gpointer data);
 gboolean fed_repo_toggled(GtkWidget * widget, gpointer data);
 gboolean fed_customization_toggled(GtkWidget * widget, gpointer data);
 gboolean fed_codecs_toggled(GtkWidget * widget, gpointer data);
 gboolean fed_tlp_toggled(GtkWidget * widget, gpointer data);
 gboolean fed_vlc_toggled(GtkWidget * widget, gpointer data);
 gboolean on_fed_window_destroy();
 gboolean debian_window(void);
 gboolean debian_info_window(void);
 gboolean on_fed_tips_window_destroy(void);
 gboolean print_asterisk_line(int asterisk_qty);
gboolean check_box_state(const gchar * command_string, GtkWidget* widget, gpointer data);
GtkWidget* create_grid(void);

#endif // LPIH_MAIN_H
